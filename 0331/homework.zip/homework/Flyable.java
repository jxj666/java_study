/*
 * @Description: 
 * @Author: jinxiaojian
 * @Email: jinxiaojian@youxin.com
 * @LastEditors: ��Ф��
 * @Date: 2019-03-31 22:59:39
 * @LastEditTime: 2019-03-31 23:17:27
 */

public interface flyable {

  double FLYLENGTH = 100.0;

  void takeoff();

  void fly();

  void land();

}